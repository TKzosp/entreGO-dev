<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    @vite('resources/css/app.css') {{-- ou use <link> se não estiver com Vite --}}
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center text-gray-800">
    {{ $slot }}
</body>
</html>