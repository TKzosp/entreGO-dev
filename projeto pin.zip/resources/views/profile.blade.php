@extends('layouts.app')
@section('title', 'Order Tracking')
@section('content')
<section class="container mx-auto p-6 min-h-[calc(100vh-5rem)] flex flex-col lg:flex-row gap-6" id="tracking">
    <h1 class="text-3xl font-semibold text-gray-800 mb-8 lg:hidden">Order Tracking</h1>
    {{-- Mapa e detalhes do pedido aqui --}}
</section>
@endsection