
<?php $__env->startSection('title', 'Order Tracking'); ?>
<?php $__env->startSection('content'); ?>
<section class="container mx-auto p-6 min-h-[calc(100vh-5rem)] flex flex-col lg:flex-row gap-6" id="tracking">
    <h1 class="text-3xl font-semibold text-gray-800 mb-8 lg:hidden">Registration</h1>
    
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\rafae\Documents\entreGO-dev\resources\views/registration.blade.php ENDPATH**/ ?>